easytimer.js
============

Easy to use Timer/Chronometer/Countdown library compatible with AMD and NodeJS

Check out the examples here: http://albert-gonzalez.github.io/easytimer.js/

Documentation will be available soon!

## Browser Support

Easytimer uses dispatchEvent, and this feature is available in these Browsers:

* Chrome (version >= 4)
* Firefox (version >= 2)
* IE (version >= 9)
* Opera (version >= 9)
* Safari (version >= 3)
* Mobile browsers
